<?php

// login error
  if(isset($_GET['error'])){
      echo "<script src='https://unpkg.com/sweetalert2@7.8.2/dist/sweetalert2.all.js'></script>";
        if($_GET['error']== 1){
            echo "<script type='text/javascript'>
                swal({
                  title: 'Oops...',
                  text: 'Username or password incorrect',
                  type: 'error',
                  confirmButtonColor: '#966FD6',
                });</script>";
        } 
  }

  // login success
  if(isset($_GET['sukses'])){
    echo "<script src='https://unpkg.com/sweetalert2@7.8.2/dist/sweetalert2.all.js'></script>";
      if($_GET['sukses']== 1){
          echo "<script type='text/javascript'>"; ?>
              swal({
                title: 'HELLO, <?php echo strtoupper($_SESSION['uname']); ?> !',
                text: 'Welcome to Admin Page',
                type: 'success',
                confirmButtonColor: '#966FD6',

                <?php 
             echo "});</script>";
      } else if($_GET['sukses']== 2){
        echo "<script type='text/javascript'>
            swal({
              title: 'Review berhasil',
              text: 'Terima kasih atas respond anda',
              type: 'success',
              confirmButtonColor: '#966FD6',
            });</script>";
    } 
}
?>