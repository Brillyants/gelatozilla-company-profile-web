<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- jquery -->
    <script src="jquery/jquery.js"></script>
    <!-- Google font -->
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!-- W3 School -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script>
        $(function() {
            $("#header").load("header.html");
        });
        $(function() {
            $("#footer").load("footer.html");
        });
    </script>
    <title>Home - Gelatozilla</title>
    <link rel="icon" href="assets/_images/menu-logo.png">
    <link rel="stylesheet" href="home.css">
</head>

<body>
    <?php include 'feedback.php';
    include 'connection.php'; ?>
    <!-- header -->
    <div id="header" class="sticky-top"></div>
    <!-- end header -->

    <!-- jumbotron -->
    <div id="section" class="p-5">
        <div class=" row align-items-center">
            <div class="col-md-6 col-sm-12 order-sm-1 p-5 text-center">
                <img id="hero-image" src="assets/_images/hero-image.png" class="img-fluid w3-animate-bottom" alt="Responsive image">
            </div>
            <div class="col-md-6 col-sm-12 order-sm-2 p-5 text-md-left text-center">
                <h1 id="hero-title" class="pb-2 anim-typewriter line-1">Gelatozilla</h1>
                <p id="hero-description" class="w3-animate-top">Satisfy your taste buds with the best.</p>
                <a href="#review-form" class="btn btn-primary w3-animate-left pt-2 pb-2"><i class="fa fa-book pr-2 "></i>Review Us</a>
            </div>
        </div>
    </div>
    <!-- end jumbotron -->

    <!-- website name -->
    <div id="section-2" class="p-5">
        <div class="row align-items-center">
            <div class="col-md-6 col-sm-12 order-sm-1 p-5 text-md-left text-center">
                <h1 id="hero-title" class="pb-2 anim-typewriter line-1">Uniqueness</h1>
                <p id="hero-description" class="w3-animate-top">Gelatozilla will always be the best dessert, just as you deserve it. Because Gelatozilla will always bring joy and fun regardless of time of day and season.</p>
                <a href="location.html">
                    <button class="btn btn-success w3-animate-left pt-2 pb-2">
                        <i class="fa fa-map pr-2"></i> Our Location
                    </button>
                </a>
            </div>
            <div class="col-md-6 col-sm-12 order-sm-2 p-5 text-center">
                <img id="section-2-image" src="assets/_images/section-2-image.jpg" class="img-fluid w3-animate-bottom" alt="Responsive image">
            </div>
        </div>
    </div>
    <!-- end website name -->

    <!-- about us -->
    <div id="section-3" class="p-5">
        <div class="row align-items-center">
            <div class="col-md-6 col-sm-12 order-sm-1 p-5 text-center">
                <img id="hero-image" src="assets/_images/hero-image.png" class="img-fluid w3-animate-bottom" alt="Responsive image">
            </div>
            <div class="col-md-6 col-sm-12 order-sm-2 p-5 text-md-left text-center">
                <h1 id="hero-title" class="pb-2 anim-typewriter line-1">About Us</h1>
                <p id="hero-description" class="w3-animate-top">A gelato business that is well-known among Jabodetabek foodies and has a number of branches throughout the city.</p>
                <a href="about.html">
                    <button class="btn btn-success w3-animate-left pt-2 pb-2">
                        <i class="fa fa-building-o pr-2"></i> About Us
                    </button>
                </a>
            </div>
        </div>
    </div>
    <!-- end about us -->

    <!-- popular menu -->
    <div id="multi-item">
        <h1 id="hero-title" class="text-center mb-5">Popular Flavors</h1>

        <!-- slides -->
        <div class="carousel-inner" role="listbox">
            <!-- first slide -->
            <div class="carousel-item active">
                <div class="row text-center">
                    <?php
                    $sth = $db->prepare("SELECT * FROM menu WHERE fav = 1 limit 4");
                    $sth->execute();
                    while ($row = $sth->fetch(PDO::FETCH_ASSOC)) {
                        $index = $row['id'];
                    ?>
                        <div class="col-md-3 p-4">
                            <div class="card mb-2 img-div">
                                <?php
                                $sth1 = $db->prepare("SELECT path_file FROM gambar where produk_id = '$index' limit 1");
                                $sth1->execute();
                                while ($row1 = $sth1->fetch(PDO::FETCH_ASSOC)) {
                                ?>
                                    <img src="<?php echo $row1['path_file']; ?>" class="card-img-top menu-hoverable">
                                    <h4 class="card-title"><?php echo $row['nama_produk']; ?></h4>
                                    <?php
                                    $bintang = $row['bintang'];
                                    switch ($bintang) {
                                        case 1:
                                    ?>
                                            <div class="card-body">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            </div>
                                    <?php
                                            break;
                                        case 2:
                                    ?>
                                            <div class="card-body">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            </div>
                                    <?php
                                            break;
                                        case 3:
                                    ?>
                                            <div class="card-body">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            </div>
                                    <?php
                                            break;
                                        case 4:
                                    ?>
                                            <div class="card-body">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                            </div>
                                    <?php
                                            break;
                                        case 5:
                                    ?>
                                            <div class="card-body">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                            </div>
                                    <?php
                                            break;
                                        default:
                                    ?>
                                            <div class="card-body">
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            </div>
                                    <?php
                                            break;
                                    }
                                    ?>
                                <?php } ?>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
    <!-- end popular menu -->

    <!-- testimonial -->
    <div id="review">
        <div class="row mt-4 text-center">
            <?php
            $sth2 = $db->prepare("SELECT * from customer limit 3");
            $sth2->execute();
            while ($row2 = $sth2->fetch(PDO::FETCH_ASSOC)) {
            ?>
                <div class="col-md-4">
                    <div class="card border-light p-1 p-md-4 mb-4 mb-lg-0" style="background-color:#bdf2ff;border-radius: 20px;transition: transform .3s;">
                        <div class="card-body">
                            <img src="<?php echo $row2['pic']; ?>" class="rounded-circle" alt="Customers" width="50%" height="50%">
                            <h2 class="card-title mb-3"><?php echo $row2['nama']; ?></h2>
                            <p class="card-text">
                                <?php echo $row2['comment']; ?>
                            </p>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
    <!-- end testimonial -->

    <!-- review form -->
    <div id="review-form" class="card card-outline-secondary">
        <h1 id="hero-title-white" class="text-center mb-5">Add Your Review</h1>
        <div class="card-body">
            <form action="review.php" method="post" autocomplete="off" class="form" role="form">
                <fieldset>
                    <label class="mb-2 mt-2" for="name">Name</label>
                    <div class="row mb-1">
                        <div class="col-lg-12">
                            <input class="form-control" id="user_name" name="nama" required="" type="text" value="">
                        </div>
                    </div>
                    <label class="mb-2 mt-2" for="message">Message</label>
                    <div class="row mb-1">
                        <div class="col-lg-12">
                            <textarea class="form-control" id="user_message" name="pesan" required="" rows="6" value=""></textarea>
                        </div>
                    </div>
                    <button class="btn btn-success btn-lg float-right mt-3" type="submit" name="submit">Submit Review</button>
                </fieldset>
            </form>
        </div>
    </div>

    <!-- end review form -->

    <!-- modal review -->
    <div class="modal fade" id="popup-modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div id="popup-modal-body" class="modal-body text-center p-5">
                    <p style="color: white;">Get up to 40% off the purchase of two <b style="color: #f79ad3;">vanilla gelatozilla</b> ice cream!!</p>
                    <button type="button" class="btn btn-success mt-2" class="close" data-dismiss="modal" aria-label="Close">Get it now!</button>
                </div>
            </div>
        </div>
    </div>
    <!-- end modal review -->

    <!-- footer -->
    <div id="footer"></div>
    <!-- end footer -->

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js " integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49 " crossorigin="anonymous "></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js " integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy " crossorigin="anonymous "></script>
    <script src="assets/scripts/home.js"></script>
</body>

</html>