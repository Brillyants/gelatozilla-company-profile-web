<?php
$koneksi = mysqli_connect("localhost", "root", "", "gelatozilla");
if (isset($_POST['submit'])) {
    mysqli_query($koneksi, "insert into review set  
                        nama = '$_POST[nama]',
                        pesan = '$_POST[pesan]'");
    header("Location: home.php?sukses=2");
}
?>
