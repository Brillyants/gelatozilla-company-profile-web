<htmL>

<head>
    <title>Admin | Gelatozilla</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/_images/menu-logo.png" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="assets/css/sidebar.css" rel="stylesheet" />
</head>
<?php session_start(); ?>


<body>
    <?php include 'feedback.php' ?>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar-->
        <div class="bg-light border-right" id="sidebar-wrapper">
            <div class="sidebar-heading">
                <a href="dashboard.php">
                    <img src="assets/_images/menu-logo.png" alt="logo" style="width: 100px; height: auto; margin-left: 40px">
                </a>
            </div>
            <!-- vertical list for menu -->
            <div class="list-group list-group-flush">
                <a class="list-group-item list-group-item-action bg-light" href="index.php?page=adminhome"><span data-feather="home"></span>&nbsp;&nbsp;Dashboard</a>
                <a class="list-group-item list-group-item-action bg-light" href="index.php?page=adminmenu"><span data-feather="coffee"></span>&nbsp;&nbsp;Menu</a>
                <a class="list-group-item list-group-item-action bg-light" href="index.php?page=adminkategori"><span data-feather="list"></span>&nbsp;&nbsp;Category</a>
                <a class="list-group-item list-group-item-action bg-light" href="index.php?page=adminreview"><span data-feather="mail"></span>&nbsp;&nbsp;Review</a>
            </div>
        </div>
        <!-- Page Content-->
        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light border-bottom" style="background: #966FD6;">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#!" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="text-light d-lg-inline"><b>GELATOZILLA ADMIN PAGE<b></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="index.php?page=adminprofile"><span data-feather="user"></span>&nbsp;&nbsp;Profile</a>

                                <!-- selipin di nav bar/butto/apapun buat logout -->
                                <?php if (isset($_SESSION['uname'])) { ?>
                                    <div class="dropdown-divider"></div> <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal"><span data-feather="log-out"></span>&nbsp;&nbsp;Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="container-fluid">
                
            </div>

            <main role="main" class="col-md-12 ml-sm-auto col-lg-12 px-4">

                <?php
                                    if (!isset($_GET['page'])) {
                                        $page = "adminhome";
                                    } else {
                                        $page = $_GET['page'];
                                    }
                                    require 'views/' . $page . '.php';
                ?>
            </main>

            <!-- Footer -->
            <footer class="sticky-footer mt-3" style="height:30px;">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span class="h6 font-weight-normal text-muted">&copy; 2022 Made by Kelompok 5</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

            <a href="#" id="toTopBtn" class="cd-top text-replace js-cd-top cd-top--is-visible cd-top--fade-out" data-abc="true"></a>
        </div>

    </div>



    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Logout</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body font-weight-normal">Are you sure you want to logout?</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-success" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JS-->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
        feather.replace()
    </script>


<?php } ?>
</body>
<script>
    $(document).ready(function() {
        $(window).scroll(function() {
            if ($(this).scrollTop() > 20) {
                $('#toTopBtn').fadeIn();
            } else {
                $('#toTopBtn').fadeOut();
            }
        });

        $('#toTopBtn').click(function() {
            $("html, body").animate({
                scrollTop: 0
            }, 1000);
            return false;
        });
    });
</script>

</html>