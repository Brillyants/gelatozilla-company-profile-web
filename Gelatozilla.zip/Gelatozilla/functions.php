<?php

$connection = mysqli_connect("localhost","root","","gelatozilla");
date_default_timezone_set('Asia/Jakarta');

function koneksiDb(){
   try {
        $dsn = "mysql:host=localhost;dbname=gelatozilla";
        $pdo = new PDO($dsn,'root','');
        return $pdo;

    } catch(PDOException $e){
        return $e;
    }
}

function checkFile($file, Array $ext_boleh, $max_size = 0){
    $ext = getFileExt($file);
    
    $ext = explode(".", $file['name']);
    $ext = end($ext);
    $ext = strtolower($ext);

    if(in_array($ext, $ext_boleh) && $file['size'] <= $max_size || $max_size == 0)
        return true;
    else
        return false;
}

function getFileExt($file){
    $ext = explode(".",$file['name']);
    $ext = end($ext);
    $ext = strtolower($ext);

    return $ext;
}

function elasped_time_ago($timestamp){
    $time_ago = strtotime($timestamp);
    $current_time = time();
    $time_difference = $current_time - $time_ago;
    $seconds = $time_difference;
    $minutes = round($seconds/60);
    $hours = round($seconds/3600);
    $days = round($seconds/86400); //24*60*60
    $weeks = round($seconds/604800); //7*24*60*60
    $months = round($seconds/2629440); //(((365*4)+366)/5/12)*24*60*60
    $years = round($seconds/31553280); //(((365*4)+366)/5)*24*60*60


    if($seconds <= 60){
        return "Just now";
    } elseif($minutes <= 60){
        if($minutes == 1)
        {
            return "One minute ago";
        } else 
        {
            return "$minutes minutes ago";
        }

    } elseif($hours <= 24){
        if($hours == 1)
        {
            return "One hour ago";
        } else
        {
            return "$hours hours ago";
        }

    } elseif($days <= 7){
        if($days == 1)
        {
            return "Yesterday";
        } else 
        {
            return "$days days ago";
        }

    } elseif($weeks <= 4.3){
        if($weeks == 1)
        {
            return "A week ago";
        } else 
        {
            return "$weeks weeks ago";
        }

    } elseif($months <= 12){
        if($months == 1)
        {
            return "A month ago";
        } else 
        {
            return "$months months ago";
        }

    } else{
        if($years == 1)
        {
            return "One year ago";
        } else 
        {
            return "$years years ago";
        }
    }
}

?>