<?php
    if(!isset($_SESSION['uname']) && !isset($_SESSION['password'])){
        session_start();
        $_SESSION['uname'] = $uname;
        $_SESSION['password'] = $password;
        $_SESSION['id'] = $id;

    }
?>