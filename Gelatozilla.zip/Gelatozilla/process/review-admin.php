<?php

require '../functions.php';

$pdo = koneksiDB();

if($_GET['action'] == "delete") {

    $sql = "DELETE FROM review
            WHERE id = ?";
    $result = $pdo->prepare($sql);
    $result->execute([$_GET['id']]);
    header('Location: ../index.php?page=adminreview');

}

?>