<?php

require '../functions.php';

$pdo = koneksiDB();

if($_GET['action'] == "add") {

    $sql = "INSERT INTO kategori (nama_kategori)
            VALUES (?)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$_POST['nama_kategori']]);
    header('Location: ../index.php?page=adminkategori');

} else if($_GET['action'] == "edit") {

    $sql = "UPDATE kategori
            SET nama_kategori = ?
            WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $_POST['nama_kategori'],
        $_POST['id']
    ]);

    header('Location: ../index.php?page=adminkategori');

} else if($_GET['action'] == "delete") {

    $sql = "DELETE FROM kategori
            WHERE id = ?";
    $result = $pdo->prepare($sql);
    $result->execute([$_GET['id']]);
    header('Location: ../index.php?page=adminkategori');

}

?>