<?php

$action = $_GET['action'];

require '../functions.php';

$pdo = koneksiDB();

if($action == "add") {

    $sql = "INSERT INTO users (user_name, password)
            VALUES (?, ?)";

    $stmt = $pdo->prepare($sql);
    
        $data = [
            $_POST['uname'],
            password_hash($_POST['password'],PASSWORD_BCRYPT)
        ];
    $stmt->execute($data);
    header('Location: ../index.php?page=adminprofile');
 } else if($_GET['action'] =="edit"){
    try {
        $sql ="UPDATE users SET user_name = ?, password = ?
    WHERE id = ?";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
        $_POST['uname'],
        password_hash($_POST['password'],PASSWORD_BCRYPT),
        $_POST['id']
    ]);

        header('Location: ../index.php?page=logoutadmin');
    }catch (PDOException $e){
        echo $sql . "<br>" . $e->getMessage();
    }

    }

?>