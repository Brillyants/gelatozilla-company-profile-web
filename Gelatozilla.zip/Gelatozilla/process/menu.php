<?php

$action = $_GET['action'];

require '../functions.php';

$pdo = koneksiDB();

if($action == "add") {

    
    //nama_produk, kategori, deskripsi, harga, fav, path_file, bintang, id
    $sql = "INSERT INTO menu (nama_produk, kategori, deskripsi, harga, fav, bintang)
            VALUES (?, ?, ?, ?, ?, ?)";
    
    // ambil nilai maximun id dari
    
    $stmt = $pdo->prepare($sql);
    

    $ext_boleh = ["jpg","png","jpeg"];
    if(checkFile($_FILES['foto'], $ext_boleh)){
        extract($_POST);
        $file_name=$_FILES["foto"]["name"];
        $file_tmp=$_FILES["foto"]["tmp_name"];
        $ext=pathinfo($file_name,PATHINFO_EXTENSION);
        $filename=basename($file_name,$ext);
        $newFileName=date('ymdhis').".".$ext;
        $file_path = "assets/_images/flavors/".$newFileName;
        

        if(!file_exists("../assets/_images/flavors/")){
            mkdir("../assets/_images/flavors/");
        }
        
        move_uploaded_file($file_tmp=$_FILES["foto"]["tmp_name"],"../assets/_images/flavors/".$newFileName);
        //upload


    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $_POST['nama_produk'],
        $_POST['kategori'],
        $_POST['deskripsi'],
        $_POST['harga'],
        $_POST['fav'],
        $_POST['bintang']
    ]);

    $querry = "SELECT * FROM menu ORDER BY id DESC LIMIT 1";
    $hasil = mysqli_query($connection,$querry);
    $jumlah = mysqli_fetch_array($hasil);
    $produk_id =$jumlah['id'];
    $sql1 = "INSERT INTO gambar (produk_id, path_file) VALUES ($produk_id, ?)";

    $stmt1 = $pdo->prepare($sql1);
    $stmt1->execute([
        $file_path
    ]);

    header('Location: ../index.php?page=adminmenu');
} else if($_GET['action'] =="edit"){
    try {
        $sql ="UPDATE menu SET nama_produk = ?, kategori = ?, deskripsi = ?, harga = ?, fav = ?, bintang = ?
        WHERE id = ?";
        $sql1 ="UPDATE gambar SET path_file = ? WHERE produk_id = ?";

        $path_file="";
        $id = $_POST['id'];
        if(empty($_POST['foto'])){
            $ext_boleh = ["jpg","png","jpeg"];
            if(checkFile($_FILES['foto'], $ext_boleh)){
                extract($_POST);
                $file_name=$_FILES["foto"]["name"];
                $file_tmp=$_FILES["foto"]["tmp_name"];
                $ext=pathinfo($file_name,PATHINFO_EXTENSION);
                $filename=basename($file_name,$ext);
                $newFileName=date('ymdhis').".".$ext;
                $file_path = "gambar/product/".$newFileName;
                

                if(!file_exists("../assets/_images/flavors/")){
                    mkdir("../assets/_images/flavors/");
                }
                
                move_uploaded_file($file_tmp=$_FILES["foto"]["tmp_name"],"../assets/_images/flavors/".$newFileName);

                $path_file = $file_path;
                echo "atas:".$file_path;
                }
            } else {
                
                $query_path_file = "SELECT * FROM gambar where produk_id = '$id' ORDER BY id DESC LIMIT 1";
                $hasil_path_file = mysqli_query($connection,$query_path_file);
                $path_file1 = mysqli_fetch_array($hasil_path_file);
                $path_file =$path_file1['path_file'];
                echo "bawah:".$path_file;
            }


        $stmt = $pdo->prepare($sql);
        $stmt->execute([
        $_POST['nama_produk'],
        $_POST['kategori'],
        $_POST['deskripsi'],
        $_POST['harga'],
        $_POST['fav'],
        $_POST['bintang'],
        $id
    ]);

        echo $path_file;
        $stmt1 = $pdo->prepare($sql1);
        $stmt1->execute([
        $path_file,
        $id
    ]);

    header('Location: ../index.php?page=adminmenu');
    }catch (PDOException $e){
        echo $sql . "<br>" . $e->getMessage();
    }

    }else if($_GET['action'] == "delete") {

    $sql = "DELETE FROM menu WHERE id=?";
    $sql1 = "DELETE FROM gambar WHERE produk_id=?";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $_GET['id']
    ]);

    $stmt1 = $pdo->prepare($sql1);
    $stmt1->execute([
        $_GET['id']
    ]);

    header('Location: ../index.php?page=adminmenu');

}

?>