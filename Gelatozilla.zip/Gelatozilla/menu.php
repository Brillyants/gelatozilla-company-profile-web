<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- jquery -->
    <script src="jquery/jquery.js"></script>
    <!-- Google font -->
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!-- W3 School -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="menu.css">
    <script>
        $(function() {
            $("#header").load("header.html");
        });
        $(function() {
            $("#footer").load("footer.html");
        });
    </script>
    <title>Menu - Gelatozilla</title>
    <link rel="icon" href="assets/_images/menu-logo.png">
</head>

<body>
    <?php include 'connection.php'; ?>

    <div id="header" class="sticky-top"></div>

    <div id="multi-item">
        <h1 id="hero-title" class="text-center mb-5">Our Flavors</h1>

        <!-- dropdown -->
        <div class="dropdown float-right">
            <button class="btn btn-primary dropdown-toggle" style="border-radius:50px; background-color:#B19CD9; border-color:#B19CD9" data-toggle="dropdown">Categories
                <span class="caret"></span>
            </button>

            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="menu.php">All</a></li>
                <?php
                $sth0 = $db->prepare("SELECT * FROM kategori");
                $sth0->execute();
                while ($row0 = $sth0->fetch(PDO::FETCH_ASSOC)) {
                ?>
                    <!-- set category dropdown name based on database -->
                    <li><a class="dropdown-item" href="menu.php?kategori=<?php echo $row0['id'] ?>"><?php echo $row0['nama_kategori'] ?></a></li>
                <?php } ?>
            </ul>
        </div>

        <!--Slides-->
        <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">
                <div class="row text-center">
                    <!-- category logics -->
                    <?php
                    if (isset($_GET['kategori'])) {
                        $kategori = $_GET['kategori'];
                        $query = "SELECT * FROM menu where kategori = '$kategori'";
                    } else {
                        $query = "SELECT * FROM menu";
                    }

                    $sth = $db->prepare($query);
                    $sth->execute();
                    while ($row = $sth->fetch(PDO::FETCH_ASSOC)) {
                        $index = $row['id'];
                    ?>
                        <div class="col-md-3 p-4">
                            <div class="card mb-2 img-div">
                                <?php
                                // get image per product
                                $sth1 = $db->prepare("SELECT path_file FROM gambar where produk_id = '$index' limit 1");
                                $sth1->execute();
                                while ($row1 = $sth1->fetch(PDO::FETCH_ASSOC)) {
                                ?>
                                    <img src="<?php echo $row1['path_file']; ?>" class="card-img-top menu-hoverable">
                                    <h4 class="card-title"><?php echo $row['nama_produk']; ?></h4>
                                    <?php
                                    $bintang = $row['bintang'];
                                    switch ($bintang) {
                                        case 1:
                                    ?>
                                            <div class="card-body">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            </div>
                                        <?php
                                            break;
                                        case 2:
                                        ?>
                                            <div class="card-body">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            </div>
                                        <?php
                                            break;
                                        case 3:
                                        ?>
                                            <div class="card-body">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            </div>
                                        <?php
                                            break;
                                        case 4:
                                        ?>
                                            <div class="card-body">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                            </div>
                                        <?php
                                            break;
                                        case 5:
                                        ?>
                                            <div class="card-body">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                            </div>
                                        <?php
                                            break;
                                        default:
                                        ?>
                                            <div class="card-body">
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            </div>
                                    <?php
                                            break;
                                    }
                                    ?>
                                <?php } ?>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>


    <div id="section-2" class="p-5">
        <div class="row align-items-center">
            <div class="col-lg-3 col-md-12 col-sm-12 order-sm-1 p-3 text-lg-left text-sm-center">
                <h1 id="hero-title" class="pb-2 w3-animate-top">Gelato Size</h1>
                <a href="location.php">
                    <button class="btn btn-success w3-animate-left pt-2 pb-2"><i class="fa fa-map pr-2"></i>Our Location</button>
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-12 order-sm-2 p-3 text-center">
                <div class="card">
                    <img class="card-img-top" src="assets/_images/size/scoop1.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5 id="size-sm" class="card-title">Small</h5>
                        <p class="card-text">Choose 1 scoop of flavor.<br> Available in cones or cups.</p>
                        <a href="location.php" class="btn btn-success"></i>Rp. 25.000</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-12 order-sm-2 p-3 text-center">
                <div class="card">
                    <img class="card-img-top" src="assets/_images/size/scoop2.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5 id="size-md" class="card-title">Medium</h5>
                        <p class="card-text">Choose 1 scoop of flavor.<br> Available in cones or cups.</p>
                        <a href="location.php" class="btn btn-success"></i>Rp. 35.000</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-12 order-sm-2 p-3 text-center">
                <div class="card">
                    <img class="card-img-top" src="assets/_images/size/jar.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5 id="size-lg" class="card-title">Large</h5>
                        <p class="card-text">Choose a maximum of 4 flavors<br> 500 ml yumminess in a jar.</p>
                        <a href="location.php" class="btn btn-success"></i>Rp. 75.000</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="footer"></div>

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js " integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49 " crossorigin="anonymous "></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js " integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy " crossorigin="anonymous "></script>
</body>

</html>