<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- jquery -->
    <script src="jquery/jquery.js"></script>
    <!-- Google font -->
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!-- W3 School -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="about.css">
    <script>
        $(function() {
            $("#header").load("header.html");
        });
        $(function() {
            $("#footer").load("footer.html");
        });
    </script>
    <title>About - Gelatozilla</title>
    <link rel="icon" href="assets/_images/menu-logo.png">
</head>

<body>
    <div id="header" class="sticky-top"></div>

    <div id="section">
        <h1 id="hero-title" class="text-center mb-5">Our Story</h1>
        <div class=" row align-items-center">
            <div class="col-md-6 col-sm-12 order-sm-1 text-center">
                <img id="hero-image" src="assets/_images/logo-gelatozzila.png" class="img-fluid w3-animate-bottom" alt="Responsive image">
            </div>
            <div class="col-md-6 col-sm-12 order-sm-2 text-md-left text-center">
                <p id="hero-description" class="w3-animate-top">
                    Starting with the story of five college students who enjoy eating gelato near their campus, they intend to launch a gelato business with a unique concept and distinct characteristics. They are committed to making their gelato with high-quality ingredients
                    at all times.
                </p>
                <a href="home.html#review-form" class="btn btn-info w3-animate-left pt-2 pb-2"><i class="fa fa-book pr-2 "></i>Review Us</a>
            </div>
        </div>
    </div>

    <div id="section-2">
        <h1 id="hero-title" class="text-center mb-5">Meet Our Founders</h1>
        <div class="row text-center">
            <div class="col-lg col-md-12 col-sm-12">
                <div class="card">
                    <img src="assets/_images/founders/aisyahaprillia.png" class="card-img-top " alt="founders">
                    <div class="card-body " style="background-color: #ffb7b2">
                        <h5 class="card-title ">Aisyah Aprilia</h5>
                        <p class="card-text ">CEO of Gelatozilla</p>
                        </i><a href="http://wa.me/6287748321436" class="btn btn-success " target="_blank"><i class="fa fa-phone pr-2 "></i>Contact Me</a>
                    </div>
                </div>
            </div>
            <div class="col-lg col-md-12 col-sm-12">
                <div class="card">
                    <img src="assets/_images/founders/andrew.png" class="card-img-top " alt="founders">
                    <div class="card-body " style="background-color: #ffdac1">
                        <h5 class="card-title ">Andrew Brillyant</h5>
                        <p class="card-text ">CTO of Gelatozilla</p>
                        </i><a href="http://wa.me/6287748321436" class="btn btn-success " target="_blank"><i class="fa fa-phone pr-2 "></i>Contact Me</a>
                    </div>
                </div>
            </div>
            <div class="col-lg col-md-12 col-sm-12">
                <div class="card">
                    <img src="assets/_images/founders/gadiel.png" class="card-img-top " alt="founders">
                    <div class="card-body" style="background-color: #e2f0cb">
                        <h5 class="card-title">Gadiel Daffa Khayru</h5>
                        <p class="card-text">CFO of Gelatozilla</p>
                        </i><a href="http://wa.me/6287748321436" class="btn btn-success " target="_blank"><i class="fa fa-phone pr-2 "></i>Contact Me</a>
                    </div>
                </div>
            </div>
            <div class="col-lg col-md-12 col-sm-12">
                <div class="card">
                    <img src="assets/_images/founders/rieva.png" class="card-img-top " alt="founders">
                    <div class="card-body " style="background-color: #b5ead7">
                        <h5 class="card-title ">Rieva Putri Safa</h5>
                        <p class="card-text ">CMO of Gelatozilla</p>
                        </i><a href="http://wa.me/6287748321436" class="btn btn-success " target="_blank"><i class="fa fa-phone pr-2 "></i>Contact Me</a>
                    </div>
                </div>
            </div>
            <div class="col-lg col-md-12 col-sm-12">
                <div class="card">
                    <img src="assets/_images/founders/rizky.png" class="card-img-top " alt="founders">
                    <div class="card-body " style="background-color: #c7ceea">
                        <h5 class="card-title ">Rizky Putra Jofansa</h5>
                        <p class="card-text ">COO of Gelatozilla</p>
                        </i><a href="http://wa.me/6287748321436" class="btn btn-success " target="_blank"><i class="fa fa-phone pr-2 "></i>Contact Me</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="footer"></div>

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js " integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49 " crossorigin="anonymous "></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js " integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy " crossorigin="anonymous "></script>
</body>

</html>