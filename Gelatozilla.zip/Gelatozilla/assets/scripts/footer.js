// show alert when someone subscribe
function subscribeResult() {
    var subBar = document.getElementById("subscribe-bar");
    var subValue = subBar.value;
    if (subValue != "") {
        alert("Hello " + subValue + ". Thanks for subscribing!");
        subBar.value = "";
    } else {
        alert("Fill in the search bar!");
    }
}