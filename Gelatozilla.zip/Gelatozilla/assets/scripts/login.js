function showLogin() {
    var user_username = document.getElementById("user_username").value;
    var user_password = document.getElementById("user_password").value;

    if (user_username != "" && user_password != "") {
        alert("Username : " + user_username + "\n" + "Password : " + user_password);
    } else {
        alert("Fill in the right information!")
    }
}