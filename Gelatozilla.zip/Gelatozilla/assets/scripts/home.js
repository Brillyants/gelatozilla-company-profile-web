// show bootstrap modal on start up
$(document).ready(function() {
    $("#popup-modal").modal();
});

// show alert when someone press search
function searchResult() {
    var searchBar = document.getElementById("search-bar");
    var searchValue = searchBar.value;
    if (searchValue != "") {
        alert("You searched for : " + searchValue);
        searchBar.value = "";
    } else {
        alert("Fill in the search bar!");
    }
}

function showReviewModal() {
    var user_name = document.getElementById("user_name").value;
    var user_email = document.getElementById("user_email").value;
    var user_message = document.getElementById("user_message").value;

    if (user_name != "" && user_email != "" && user_message != "") {
        alert("Nama : " + user_name + "\n" + "Email : " + user_email + "\n" + "Message : " + user_message);
    }
}

// smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});