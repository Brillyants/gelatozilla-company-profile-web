var path = window.location.pathname;
var page = path.split("/").pop();
const menuList = document.querySelectorAll('li');
switch (page) {
    case "home.html":
        menuList[0].className = "nav-item active";
        break;
    case "menu.html":
        menuList[1].className = "nav-item active";
        break;
    case "location.html":
        menuList[2].className = "nav-item active";
        break;
    case "about.html":
        menuList[3].className = "nav-item active";
        break;
    default:
        console.log("error");
}

// resize navbar after scroll
window.onscroll = function() { scrollFunction() };

function scrollFunction() {
    if (document.body.scrollTop > 40 || document.documentElement.scrollTop > 40) {
        document.getElementById("logo").style.width = "70%";
        document.getElementById("logo").style.height = "70%";
    } else {
        document.getElementById("logo").style.width = "90%";
        document.getElementById("logo").style.height = "90%";
    }
}