function showSignUp() {
    var user_email = document.getElementById("user_email").value;
    var user_username = document.getElementById("user_username").value;
    var user_password = document.getElementById("user_password").value;
    var user_confirm_password = document.getElementById("user_confirm_password").value;

    if (user_email != "" && user_username != "" && user_password != "" && user_confirm_password != "" && user_password == user_confirm_password) {
        alert("Email : " + user_email + "\n" + "Username : " + user_username + "\n" + "Password : " + user_password + "\n" + "Confirm Password : " + user_confirm_password);
    } else {
        alert("Fill in the right information!")
    }
}