<?php
require 'functions.php';
$pdo = koneksiDb();
$sql = "SELECT menu.id, gambar.path_file as foto, menu.nama_produk, kategori.nama_kategori as kategori, menu.deskripsi, menu.harga, menu.fav as favorit, menu.bintang 
    FROM menu 
    JOIN kategori ON menu.kategori = kategori.id 
    JOIN gambar ON menu.id = gambar.produk_id";
$hasil = $pdo->query($sql);

?>

<h1 class="lead mt-3" style="color: #335749; font-size:30px;">Menu</h1>

<a href="index.php?page=menu-form&action=add" class="btn btn-success">
    <span data-feather="plus-circle"></span> Buat Menu Baru</a>

<div class="table-responsive mt-3">
    <table class="table">
        <tr>
            <th>No.</th>
            <th>Gambar Produk</th>
            <th>Nama Produk</th>
            <th>Kategori</th>
            <th>Deskripsi</th>
            <th>Harga</th>
            <th>Favorit</th>
            <th>Bintang</th>
            <th>Tindakan</th>
        </tr>
        <?php
        $i = 0;
        while ($row = $hasil->fetch()) :
            $i++;
        ?>
            <tr>
                <td> <?= $i; ?> </td>
                <td>
                    <img src="<?= $row['foto']; ?>" style="width:150px; height:autopx">
                </td>
                <td> <?= $row['nama_produk']; ?> </td>
                <td> <?= $row['kategori']; ?></td>
                <td> <?= $row['deskripsi']; ?> </td>
                <td> <?= $row['harga']; ?> </td>
                <td> <?= $row['favorit']; ?> </td>
                <td> <?= $row['bintang']; ?> </td>
                <td>
                    <a href="index.php?page=menu-form&action=view&id=<?= $row['id']; ?>" class="btn btn-primary btn-sm">
                        <span data-feather="eye"></span> Lihat</a>
                    <a href="index.php?page=menu-form&action=edit&id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">
                        <span data-feather="edit"></span> Ubah</a>
                    <a href="process/menu.php?action=delete&id=<?= $row['id']; ?>" class="btn btn-danger btn-sm">
                        <span data-feather="trash"></span> Hapus</a>


                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>