<?php

require 'functions.php';
$id = $_SESSION['id'];
$uname = $_SESSION['uname'];
$password = $_SESSION['password'];

?>

<h1 class="lead mt-3" style="color: #335749; font-size:30px;">Profile</h1>

<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card card-user">
                <div class="card-header">
                    <h5 class="card-title">Edit Profile</h5>
                </div>
                <div class="card-body">
                    <form>
                        <div class="row">
                            <div class="col-md-6 pr-1">
                                <div class="form-group">
                                    <label>Username</label>
                                    <input type="text" class="form-control" disabled="" placeholder="Username" value="<?php echo $_SESSION['uname'] ?>">
                                </div>
                            </div>
                            <div class="col-md-6 px-1">
                                <div class="form-group">
                                    <label>Password</label>
                                    <input type="password" class="form-control" disabled="" placeholder="Password" value="<?php echo $_SESSION['password'] ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 pr-1">
                                <div class="form-group">
                                    <label>Perusahaan</label>
                                    <input type="text" class="form-control" disabled="" placeholder="Company" value="Gelatozilla">
                                </div>
                            </div>
                            <div class="col-md-8 px-1">
                                <div class="form-group">
                                    <label>Alamat</label>
                                    <input type="text" class="form-control" disabled="" placeholder="Home Address" value="Jl. Scientia Boulevard, Gading, Kec. Serpong, Tangerang, Banten 15227">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 pr-1">
                                <div class="form-group">
                                    <label>Kota</label>
                                    <input type="text" class="form-control" disabled="" placeholder="City" value="Tangerang">
                                </div>
                            </div>
                            <div class="col-md-6 px-1">
                                <div class="form-group">
                                    <label>Negara</label>
                                    <input type="text" class="form-control" disabled="" placeholder="Country" value="Indonesia">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" class="form-control" id="id" name="id" value="<?= $id ?>">
                        <div class="row">
                            <div class="col-md-12 pr-1">
                                <a href="index.php?page=profile-form&action=add" class="btn btn-primary">
                                    Buat Profile Baru</a>

                                <a href="index.php?page=profile-form-edit&action=edit&id=<?= $_SESSION['id']; ?>" class="btn btn-primary">
                                    Edit Profile</a>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>