<?php
require 'functions.php';
$pdo = koneksiDb();
$sql = "SELECT * FROM menu";
$hasil = $pdo->query($sql);
?>

<h1 class="lead mt-3" style="color: #335749; font-size:30px;">Dashboard</h1>

<!-- Content Row -->
<div class="row">
    <!-- Total Admin -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Admin</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $query = "SELECT id from users ORDER BY id";
                            $query_run = mysqli_query($connection, $query);

                            $row = mysqli_num_rows($query_run);

                            echo '<h1>' . $row . '</h1>';
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <span data-feather="users"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Kategori -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Kategori</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $query = "SELECT id from kategori ORDER BY id";
                            $query_run = mysqli_query($connection, $query);

                            $row = mysqli_num_rows($query_run);

                            echo '<h1>' . $row . '</h1>';
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <span data-feather="grid"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Lokasi -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                            Lokasi</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $query = "SELECT id from lokasi ORDER BY id";
                            $query_run = mysqli_query($connection, $query);

                            $row = mysqli_num_rows($query_run);

                            echo '<h1>' . $row . '</h1>';
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <span data-feather="map-pin"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Review -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Review</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $query = "SELECT id from review ORDER BY id";
                            $query_run = mysqli_query($connection, $query);

                            $row = mysqli_num_rows($query_run);

                            echo '<h1>' . $row . '</h1>';
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <span data-feather="message-circle"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-lg-4 mb-4">
        <div class="card shadow mb-4" style="width: 18rem;">
            <div class="card-header m-0 text-dark">
                <h6 class="text-xs font-weight-bold text-dark text-center text-uppercase mb-1 m-0">Total Menu: &nbsp;
                    <?php
                    $query = "SELECT id from menu ORDER BY id";
                    $query_run = mysqli_query($connection, $query);

                    $row = mysqli_num_rows($query_run);

                    echo $row;
                    ?>
                </h6>

            </div>
            <ul class="list-group list-group-flush">
                <?php
                while ($row = $hasil->fetch()) :
                ?>
                    <li class="list-group-item font-weight-normal"><?= $row['nama_produk']; ?></li>
                <?php endwhile; ?>
            </ul>
        </div>
    </div>

    <div class="col-lg-8 mb-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="text-xs font-weight-bold text-dark text-center text-uppercase mb-1 m-0">Review from Influencer's</h6>
            </div>
            <div class="card-body">
                <div class="text-center">
                    <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 25rem;" src="assets/_images/client/nexcarlos.jpg" alt="nexcarlos">
                </div>
                <p class="font-weight-normal text-justify">"Toko gelato ini ramenya bukan main. Gelatozilla, my man! Enak, lembut, padet. Rum & raisin nya kacau enak banget! Yang varian buah-buahan seger banget berasa minum jus buah, dan yang tiramisu kopinya bukan sembarang kopi."</p>
                <a target="_blank" rel="nofollow" href="index.php?page=adminreview">Browse more in review &rarr;</a>
            </div>
        </div>
    </div>

</div>