<?php

if ($_GET['action'] == "add") {
    $page_title = "Buat Kategori Baru";

    $nama_kategori = "";
    $id = "";
} elseif ($_GET['action'] == "edit") {
    $page_title = "Ubah Kategori";

    require 'functions.php';
    $pdo = koneksiDb();
    $sql = "SELECT * FROM kategori WHERE id = ?";
    $hasil = $pdo->prepare($sql);
    $hasil->execute([$_GET['id']]);

    $row = $hasil->fetch();

    $nama_kategori = $row['nama_kategori'];
    $id = $row['id'];
}
?>

<h1 class="lead mt-3" style="color: #335749; font-size:30px;"><?= $page_title; ?> </h1>
<form action="process/kategori.php?action=<?= $_GET['action']; ?>" method="post">
    <div class="form-group">
        <label>Nama Kategori</label>
        <input type="text" name="nama_kategori" value="<?= $nama_kategori; ?>" class="form-control" required />

    </div>
    <input type="hidden" name="id" value="<?= $id; ?>">
    <button type="submit" class="btn btn-success">Save</button>
</form>