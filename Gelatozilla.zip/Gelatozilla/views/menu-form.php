<?php
$action = $_GET['action'];
require 'functions.php';
$pdo = koneksiDb();
$sql = "SELECT * FROM kategori";

$hasil = $pdo->query($sql);

if ($action == "add") {
    $page_title = "Buat Menu Baru";
    $nama_produk = "";
    $nama_kategori = "";
    $deskripsi = "";
    $harga = "";
    $fav = "";
    $foto = "";
    $bintang = "";
} else if ($action == "edit") {
    $page_title = "Edit Menu";
    $sql = "SELECT menu.id, gambar.path_file as foto, menu.nama_produk,  menu.kategori, kategori.nama_kategori, menu.deskripsi, menu.harga, menu.fav, menu.bintang 
    FROM menu 
    JOIN kategori ON menu.kategori = kategori.id 
    JOIN gambar ON menu.id = gambar.produk_id 
    WHERE menu.id = ?";


    $hasil = $pdo->prepare($sql);
    $hasil->execute([$_GET['id']]);
    $row = $hasil->fetch();

    $sql1 = "SELECT * FROM kategori";
    $hasil1 = $pdo->query($sql1);

    $nama_produk = $row['nama_produk'];
    $nama_kategori = $row['nama_kategori'];
    $kategori = $row['kategori'];
    $deskripsi = $row['deskripsi'];
    $harga = $row['harga'];
    $fav = $row['fav'];
    $bintang = $row['bintang'];

} else if ($action == "view") {
    $page_title = "View Menu";
    $sql = "SELECT menu.id, gambar.path_file as foto, menu.nama_produk, menu.kategori, kategori.nama_kategori, menu.deskripsi, menu.harga, menu.fav, menu.bintang 
    FROM menu 
    JOIN kategori ON menu.kategori = kategori.id 
    JOIN gambar ON menu.id = gambar.produk_id 
    WHERE menu.id = ?";

    $sql2 = "SELECT * FROM gambar where produk_id = ?";
    $hasil2 = $pdo->prepare($sql2);
    $hasil2->execute([$_GET['id']]);
    $row2 = $hasil2->fetch();
    $gambar = $row2['path_file'];

    $hasil = $pdo->prepare($sql);
    $hasil->execute([$_GET['id']]);
    $row = $hasil->fetch();

    $sql1 = "SELECT * FROM kategori";
    $hasil1 = $pdo->query($sql1);


    $nama_produk = $row['nama_produk'];
    $nama_kategori = $row['nama_kategori'];
    $kategori = $row['kategori'];
    $deskripsi = $row['deskripsi'];
    $harga = $row['harga'];
    $fav = $row['fav'];
    $bintang = $row['bintang'];
}

?>


<h1 class="lead mt-3" style="color: #335749; font-size:30px;"><?= $page_title; ?> </h1>
<form action="process/menu.php?action=<?= $action ?>" method="post" enctype="multipart/form-data">

    <div class="form-group">
        <label>Nama Produk</label>
        <?php
        if ($action == "view") { ?>
            <input type="text" name="nama_produk" value="<?= $nama_produk ?>" class="form-control" readonly />
        <?php } else { ?>
            <input type="text" name="nama_produk" value="<?= $nama_produk ?>" class="form-control" required />
        <?php } ?>
    </div>

    <div class="form-group">
        <label>Kategori</label>
        <?php
        if ($action == "view") { ?>
            <select name="kategori" class="form-control" disabled>
                <?php while ($nama_kategori = $hasil1->fetch()) : ?>
                    <option value="<?= $nama_kategori['id'] ?>"> <?= $nama_kategori['nama_kategori'] ?> </option>
                <?php endwhile; ?>
            </select>
        <?php } else { ?>
            <select name="kategori" class="form-control" required>
                <?php
                if ($action == "add") {
                    while ($nama_kategori = $hasil->fetch()) : ?>
                        <option value="<?= $nama_kategori['id'] ?>"><?= $nama_kategori['nama_kategori'] ?></option>
                    <?php endwhile;
                } else {
                    while ($nama_kategori = $hasil1->fetch()) : ?>
                        <option value="<?= $nama_kategori['id'] ?>"><?= $nama_kategori['nama_kategori'] ?></option>
                <?php endwhile;
                }
                ?>
            </select>
        <?php }
        ?>
    </div>

    <div class="form-group">
        <label>Deskripsi</label>
        <?php
        if ($action == "view") { ?>
            <input type="text" name="deskripsi" value="<?= $deskripsi ?>" class="form-control" readonly>
        <?php } else { ?>
            <input type="text" name="deskripsi" value="<?= $deskripsi ?>" class="form-control" required>
        <?php }
        ?>
    </div>

    <div class="form-group">
        <label>Harga</label>
        <?php
        if ($action == "view") { ?>
            <input type="text" name="harga" value="<?= $harga ?>" class="form-control" readonly />
        <?php } else { ?>
            <input type="text" name="harga" value="<?= $harga ?>" class="form-control" required />
        <?php }
        ?>

    </div>

    <div class="form-group">
        <label>Favorit</label><br>
        <?php
        if ($action == "add") { ?>
            <label class="font-weight-normal"><input type="radio" name="fav" value="0" required /> &nbsp;&nbsp; Tidak Favorit</label>
            &emsp;&emsp;
            <label class="font-weight-normal"><input type="radio" name="fav" value="1" required /> &nbsp;&nbsp; Favorit</label>
        <?php
        } elseif ($action == "view") { ?>
            <label class="font-weight-normal"><input type="radio" name="fav" value="0" <?php echo ($fav == '0') ? 'checked="checked"' : ''; ?> disabled /> &nbsp;&nbsp; Tidak Favorit</label>
            &emsp;&emsp;
            <label class="font-weight-normal"><input type="radio" name="fav" value="1" <?php echo ($fav == '1') ? 'checked="checked"' : ''; ?> disabled /> &nbsp;&nbsp; Favorit</label>
        <?php
        } else { ?>
            <label class="font-weight-normal"><input type="radio" name="fav" value="0" <?php echo ($fav == '0') ? 'checked="checked"' : ''; ?> /> &nbsp;&nbsp; Tidak Favorit</label>
            &emsp;&emsp;
            <label class="font-weight-normal"><input type="radio" name="fav" value="1" <?php echo ($fav == '1') ? 'checked="checked"' : ''; ?> /> &nbsp;&nbsp; Favorit</label>
        <?php
        } ?>
    </div>

    <div class="form-group">
        <label>Foto</label><br>
        <?php
        if ($action == "view") {
        ?> <img class="img-fluid img-thumbnail" style="width:300px; height:auto;" src="<?php echo $gambar ?>"> <?php
                                                                                                            } else { ?>
            <input type="file" name="foto" required />
        <?php
                                                                                                            }
        ?>
    </div>

    <div class="form-group">
        <label>Bintang</label>


        <?php
        if ($action == "view") { ?>
            <input type="number" name="bintang" value="<?= $bintang ?>" class="form-control" min="1" max="5" readonly />
        <?php } else { ?>
            <input type="number" name="bintang" value="<?= $bintang ?>" class="form-control" min="1" max="5" required>
        <?php }
        ?>

    </div>


    <input type="hidden" name="id" value="<?= $_GET['id'] ?>">
    <?php
    if ($action == "add") { ?>
        <button type="submit" class="btn btn-success">Save</button>
    <?php } else if ($action == "edit") { ?>
        <button type="submit" class="btn btn-success">Save</button>
    <?php }
    ?>


</form>