<!DOCTYPE html>

<html>

<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
  <style>
    /* toggle password*/
    .wrapper {
      position: relative;
      border-radius: 5px;
    }

    .wrapper span {
      position: absolute;
      right: 15px;
      top: 25%;
      transform: translateY(-50%);
      font-size: 20px;
      cursor: pointer;
      display: none;
    }

    .wrapper input:valid~span {
      display: block;
    }

    .wrapper span i.hide-btn::before {
      content: "\f070";
    }

    input {
      display: block;
      border: 2px solid #ccc;
      width: 95%;
      padding: 10px;
      margin: 10px auto;
      border-radius: 5px;
      box-sizing: border-box;
    }
  </style>

</head>

<body>

  <?php

  if ($_GET['action'] == "add") {
    $page_title = "Buat Profile Baru";

    $uname = "";
    $password = "";
    $id = "";
  } elseif ($_GET['action'] == "edit") {
    $page_title = "Ubah Profile";

    require 'functions.php';
    $pdo = koneksiDb();
    $sql = "SELECT * FROM users WHERE id = ?";
    $hasil = $pdo->prepare($sql);
    $hasil->execute([$_GET['id']]);

    $row = $hasil->fetch();

    $uname = $_SESSION['uname'];
    $password = $_SESSION['password'];
    $id = $_SESSION['id'];
  }

  ?>

  <h1 class="h2 mt-3"><?= $page_title; ?> </h1>
  <form action="process/profileedit.php?action=<?= $_GET['action']; ?>" method="post">

    <div class="form-group">
      <label>Username</label>
      <input type="text" name="uname" value="<?= $uname; ?>" class="form-control" required />
      <input type="hidden" name="id" value="<?= $id; ?>" class="form-control" />
    </div>
    <div class="form-group">
      <label>Password</label>
      <!-- <input type="password" name="password" value="<= $password; ?>" class="form-control" required/> -->
      <div class="wrapper">
        <input type="password" name="password" value="<?= $password; ?>" class="form-control" required /> <br>
        <span class="show-btn"><i class="fas fa-eye"></i></span>
      </div>

    </div>

    <button type="submit" class="btn btn-success" onclick="myFunction()">Save</button>

    <script type="text/javascript">
      const passField = document.querySelector('input[name="password"]');
      const showBtn = document.querySelector("span i");
      showBtn.onclick = (() => {
        if (passField.type === "password") {
          passField.type = "text";
          showBtn.classList.add("hide-btn");
        } else {
          passField.type = "password";
          showBtn.classList.remove("hide-btn");
        }
      });
    </script>

  </form>

  <script>
    function myFunction() {
      alert("Data berhasil diupdate. Silakan log in kembali.");

    }
  </script>