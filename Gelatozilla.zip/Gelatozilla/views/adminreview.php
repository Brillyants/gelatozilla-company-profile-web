<?php
require 'functions.php';
$pdo = koneksiDb();
$sql = "SELECT * FROM review";
$hasil = $pdo->query($sql);
?>

<h1 class="lead mt-3" style="color: #335749; font-size:30px;">Review</h1>
<div class="container-fluid">
    <div class="card-deck">
        <?php
        while ($row = $hasil->fetch()) :
        ?>
            <div class="row justify-contect-center">
                <div class="card shadow" style="background: #FABA1A; width: 18rem; margin-left: 30px; margin-bottom: 20px; justify-content: space-around; display: flex;">
                    <div class="card-body">
                        <h4 class="card-title text-center text-white"><?= $row['nama']; ?></h4>
                        <hr />
                        <p class="card-text font-weight-normal text-justify text-dark" style="font-size:12pt;"><?= $row['pesan']; ?> <br></p>
                    </div>
                    <a href="process/review-admin.php?action=delete&id=<?= $row['id']; ?>" class="align-self-end btn btn-danger float-right btn-sm my-2 mx-2"><span data-feather="trash"></span></a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>