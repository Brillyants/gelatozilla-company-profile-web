<?php
require 'functions.php';
$pdo = koneksiDb();
$sql = "SELECT * FROM kategori";
$hasil = $pdo->query($sql);
?>

<h1 class="lead mt-3" style="color: #335749; font-size:30px;">Kategori Makanan</h1>
<a href="index.php?page=kategori-form&action=add" class="btn btn-success">
    <span data-feather="plus-circle"></span> Buat Kategori Baru</a>
<div class="table-responsive mt-3">
    <table class="table">
        <tr>
            <th>No.</th>
            <th>Nama Kategori</th>
            <th>Tindakan</th>
        </tr>
        <?php
        $i = 0;
        while ($row = $hasil->fetch()) :
            $i++;
        ?>
            <tr>
                <td><?= $i; ?></td>
                <td><?= $row['nama_kategori']; ?></td>
                <td>
                    <a href="index.php?page=kategori-form&action=edit&id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">
                        <span data-feather="edit"></span> Ubah</a>
                    <a href="process/kategori.php?action=delete&id=<?= $row['id']; ?>" class="btn btn-danger btn-sm">
                        <span data-feather="trash"></span> Hapus</a>

                </td>
            </tr>
        <?php endwhile;   ?>
    </table>
</div>