-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2022 at 10:49 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gelatozilla`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `nama`, `pic`, `comment`) VALUES
(1, '@eatandtreats', 'assets/_images/client/eatandtreats.jpg', 'Jujur agak sulit nyari gelato di wilayah Jakarta yang rasanya authentic. Tapi, akhirnya nemu Gelatozilla yang fortunately cabangnya kesebar di wilayah Jakarta & Tangerang. Pistachio dan stracciatella-nya wajib coba. Very comforting, simple yet so good'),
(2, '@nexcarlos', 'assets/_images/client/nexcarlos.jpg', 'Toko gelato ini ramenya bukan main. Gelatozilla, my man! Enak, lembut, padet. Rum & raisin nya kacau enak banget! Yang varian buah-buahan seger banget berasa minum jus buah, dan yang tiramisu kopinya bukan sembarang kopi.'),
(3, '@tasyiiathasyia', 'assets/_images/client/tasyiiathasyia.jpg', 'Ingredients yang mereka pake bukan main-main. Aku personally kurang suka gelato yang manis, tapi ini semuanya pas! Rasanya gak berlebihan, fresh, dan natural. Aku paling suka teksturnya, sih.');

-- --------------------------------------------------------

--
-- Table structure for table `gambar`
--

CREATE TABLE `gambar` (
  `id` int(11) NOT NULL,
  `produk_id` int(11) NOT NULL,
  `path_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gambar`
--

INSERT INTO `gambar` (`id`, `produk_id`, `path_file`) VALUES
(1, 1, 'assets/_images/flavors/birthday-cake-ice-cream.jpg'),
(2, 2, 'assets/_images/flavors/biscoff.jpg'),
(3, 3, 'assets/_images/flavors/blueberry.jpg'),
(4, 4, 'assets/_images/flavors/bubblegum.jpg'),
(5, 5, 'assets/_images/flavors/choco-mint.jpg'),
(6, 6, 'assets/_images/flavors/cookies-n-cream.jpg'),
(7, 7, 'assets/_images/flavors/french-vanilla.jpg'),
(8, 8, 'assets/_images/flavors/fudgy-brownies.jpg'),
(9, 9, 'assets/_images/flavors/matcha.jpg'),
(10, 10, 'assets/_images/flavors/pistachio.jpeg'),
(11, 11, 'assets/_images/flavors/rum_raisin.jpg'),
(12, 12, 'assets/_images/flavors/salted-caramel.jpg'),
(13, 13, 'assets/_images/flavors/stracciatella.jpg'),
(14, 14, 'assets/_images/flavors/strawberry-cheesecake.jpg'),
(15, 15, 'assets/_images/flavors/strawberry.jpg'),
(16, 16, 'assets/_images/flavors/thai-tea.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama_kategori`) VALUES
(1, 'Fruity'),
(2, 'Soft'),
(3, 'Crispy');

-- --------------------------------------------------------

--
-- Table structure for table `lokasi`
--

CREATE TABLE `lokasi` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `jam` varchar(100) NOT NULL,
  `path_file` varchar(255) NOT NULL,
  `domisili` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lokasi`
--

INSERT INTO `lokasi` (`id`, `nama`, `alamat`, `telepon`, `jam`, `path_file`, `domisili`) VALUES
(1, 'Muara Karang', 'Jl. Mawar no. 13', '081298153977', 'Open for 24 Hours', 'assets/_images/location/loc1.jpg', 'Jakarta'),
(2, 'Emporium', 'Jl. Melati no. 14', '081298153966', 'Open for 24 Hours', 'assets/_images/location/loc2.jpg', 'Jakarta'),
(3, 'Pantai Indak Kapuk', 'Jl. Anggrek no. 15', '081298154001', 'Open for 24 Hours', 'assets/_images/location/loc3.jpg', 'Jakarta'),
(4, 'Sunter', 'Jl. Kencana no. 16', '081298159022', 'Open for 24 Hours', 'assets/_images/location/loc4.jpg', 'Jakarta'),
(5, 'Kelapa Gading', 'Jl. Merah no. 16', '08129811111', 'Open for 24 Hours', 'assets/_images/location/loc5.jpg', 'Tangerang'),
(6, 'Gading Serpong', 'Jl. Hijau no. 17', '081298152020', 'Open for 24 Hours', 'assets/_images/location/loc6.jpg', 'Tangerang'),
(7, 'Alam Sutera', 'Jl. Kuning no. 18', '081298152022', 'Open for 24 Hours', 'assets/_images/location/loc7.jpg', 'Tangerang'),
(8, 'Bintaro Jaya', 'Jl. Coklat no. 19', '081298152003', 'Open for 24 Hours', 'assets/_images/location/loc8.jpg', 'Tangerang');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `kategori` int(11) NOT NULL,
  `deskripsi` varchar(255) NOT NULL,
  `harga` int(11) NOT NULL,
  `fav` int(11) NOT NULL,
  `bintang` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `nama_produk`, `kategori`, `deskripsi`, `harga`, `fav`, `bintang`) VALUES
(1, 'Birthday Cream', 1, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.\r\n\r\n', 35000, 0, 5),
(2, 'Biscoff', 3, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.\r\n\r\n', 35000, 0, 5),
(3, 'Blueberry', 1, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 1, 5),
(4, 'Bubble Gum', 2, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 0, 4),
(5, 'Choco Mint', 2, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 1, 5),
(6, 'Cookies n\' Cream', 3, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 1, 5),
(7, 'French Vanilla', 2, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 0, 4),
(8, 'Fudy Brownies', 2, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 0, 4),
(9, 'Matcha', 2, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 0, 5),
(10, 'Pistachio', 3, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 0, 4),
(11, 'Rum Raisin', 2, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 0, 5),
(12, 'Salted Caramel', 2, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 0, 5),
(13, 'Stracciatella', 2, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 0, 4),
(14, 'Strawberry Cheesecake', 1, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 1, 5),
(15, 'Strawberry', 1, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 0, 4),
(16, 'Thai Tea', 2, 'Many people loves them because they are so crispy, delicious and the sweet and sour sauce makes them even more appetizing.', 35000, 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `pesan` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`id`, `nama`, `pesan`) VALUES
(1, 'Andrew', 'Thomas');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`) VALUES
(1, 'admin1', '$2a$12$UuW/0PJ0e5Qtn9CklxWs0uVggTLQq12Zn03J1qoYo.wKVl7PRqoYO');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gambar`
--
ALTER TABLE `gambar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `produk_id` (`produk_id`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lokasi`
--
ALTER TABLE `lokasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kategori` (`kategori`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `gambar`
--
ALTER TABLE `gambar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `lokasi`
--
ALTER TABLE `lokasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gambar`
--
ALTER TABLE `gambar`
  ADD CONSTRAINT `gambar_ibfk_1` FOREIGN KEY (`produk_id`) REFERENCES `menu` (`id`);

--
-- Constraints for table `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`kategori`) REFERENCES `kategori` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
