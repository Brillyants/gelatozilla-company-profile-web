<?php
session_start();
include "login_conn.php";

if (isset($_POST['uname']) && isset($_POST['password'])){
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $uname = $_POST['uname'];
    $password = $_POST['password'];
    
    if (empty($uname) or empty($password)) {
        header("Location: adminlogin.php");
        exit();
    }
    else {
        $sql = "SELECT * FROM users WHERE user_name='$uname'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);
            if ($row['user_name'] === $uname && password_verify($password, $row['password'])){
                $id = $row['id'];
                include 'session.php';
                header("Location: dashboard.php?sukses=1");
            } else {
                header("Location: adminlogin.php?error=1");
                exit();
            }
        }else{
            header("Location: adminlogin.php?error=1");
            exit(); 
        }

    }
    } else {
    header("Location: adminlogin.php");
    exit();
}

    
?>
