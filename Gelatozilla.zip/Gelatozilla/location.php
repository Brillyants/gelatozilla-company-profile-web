<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- jquery -->
    <script src="jquery/jquery.js"></script>
    <!-- Google font -->
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!-- W3 School -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="location.css">
    <script>
        $(function() {
            $("#header").load("header.html");
        });
        $(function() {
            $("#footer").load("footer.html");
        });
    </script>
    <title>Location - Gelatozilla</title>
    <link rel="icon" href="assets/_images/menu-logo.png">
</head>

<body>
    <div id="header" class="sticky-top"></div>
    <?php include 'connection.php'; ?>

    <div id="section">
        <h1 id="hero-title" class="text-center">Jakarta</h1>
        <div class="row">
            <?php
            $sth = $db->prepare("SELECT * FROM lokasi WHERE domisili = 'Jakarta'");
            $sth->execute();
            while ($row = $sth->fetch(PDO::FETCH_ASSOC)) {
            ?>
                <div class="col-md-3 col-sm-12 text-md-left text-center p-4">
                    <a href="https://goo.gl/maps/GgZ3vGooHhPrkxA9A" target="_blank"><img src="<?php echo $row['path_file']; ?>" class="img-fluid w3-animate-bottom rounded-img-custom" alt="Responsive image"></a>
                </div>
                <div class="col-md-3 col-sm-12 text-md-left text-center my-auto">
                    <h3>Gelatozilla</h3>
                    <h4> <?php echo $row['nama']; ?></h4>
                    <a href="https://goo.gl/maps/GgZ3vGooHhPrkxA9A" target="_blank"><i class="fa fa-map-pin pr-2"></i> <?php echo $row['alamat']; ?></a>
                    <p><i class="fa fa-phone pr-2"></i> <?php echo $row['telepon']; ?></p>
                    <p><i class="fa fa-map pr-2"></i> <?php echo $row['jam']; ?></p>
                </div>
            <?php } ?>
        </div>
    </div>

    <div id="section-2">
        <h1 id="hero-title" class="text-center">Tangerang</h1>
        <div class="row">
        <?php
            $sth2 = $db->prepare("SELECT * FROM lokasi WHERE domisili = 'Tangerang'");
            $sth2->execute();
            while ($row2 = $sth2->fetch(PDO::FETCH_ASSOC)) {
            ?>
                <div class="col-md-3 col-sm-12 text-md-left text-center p-4">
                    <a href="https://goo.gl/maps/GgZ3vGooHhPrkxA9A" target="_blank"><img src="<?php echo $row2['path_file']; ?>" class="img-fluid w3-animate-bottom rounded-img-custom" alt="Responsive image"></a>
                </div>
                <div class="col-md-3 col-sm-12 text-md-left text-center my-auto">
                    <h3>Gelatozilla</h3>
                    <h4> <?php echo $row2['nama']; ?></h4>
                    <a href="https://goo.gl/maps/GgZ3vGooHhPrkxA9A" target="_blank"><i class="fa fa-map-pin pr-2"></i> <?php echo $row2['alamat']; ?></a>
                    <p><i class="fa fa-phone pr-2"></i> <?php echo $row2['telepon']; ?></p>
                    <p><i class="fa fa-map pr-2"></i> <?php echo $row2['jam']; ?></p>
                </div>
            <?php } ?>
        </div>
    </div>

    <div id="footer"></div>

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js " integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49 " crossorigin="anonymous "></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js " integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy " crossorigin="anonymous "></script>
</body>

</html>